# Spam Detection using Machine Learning

## Overview
This project uses the SMS Spam Collection dataset to train a Naive Bayes classifier to detect spam messages.

## Features
- Preprocessing with NLTK
- Feature extraction using TF-IDF
- Model training with Multinomial Naive Bayes
- Command-line prediction interface
- Saved model for reuse

## Installation
```bash
pip install -r requirements.txt
```

## Run CLI App
```bash
python app/spam_detector.py
```

## Dataset
Dataset is included in the `data/spam.csv` file.
