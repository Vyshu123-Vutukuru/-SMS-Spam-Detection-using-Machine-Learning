import joblib
import sys

model = joblib.load('model/spam_classifier.pkl')
vectorizer = joblib.load('model/tfidf_vectorizer.pkl')

print("Enter your message:")
message = input("> ")
vectorized = vectorizer.transform([message])
prediction = model.predict(vectorized)
print("SPAM" if prediction[0] == 1 else "HAM")
